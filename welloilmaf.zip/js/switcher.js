	
//=== Switcher panal slide function	=====================//


	jQuery('.switch-btn').on('click', function () { 
		jQuery('.styleswitcher').toggleClass('active');
	});
 

//=== Switcher panal slide function END	=====================//


//=== Color css change function	=====================//

jQuery( document ).ready(function() {
	
    // Color changer
    jQuery(".skin-1").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-1.css");
		jQuery(".logo-header img").attr("src", "images/logo-1.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-1.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-1.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-1.png");
        return false;
    });
    
    jQuery(".skin-2").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-2.css");
		jQuery(".logo-header img").attr("src", "images/logo-2.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-2.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-2.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-2.png");
        return false;
    });
    
    jQuery(".skin-3").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-3.css");
		jQuery(".logo-header img").attr("src", "images/logo-3.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-3.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-3.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-3.png");
        return false;
    });
	
    jQuery(".skin-4").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-4.css");
		jQuery(".logo-header img").attr("src", "images/logo-4.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-4.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-4.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-4.png");
        return false;
    });
	
    jQuery(".skin-5").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-5.css");
		jQuery(".logo-header img").attr("src", "images/logo-5.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-5.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-5.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-5.png");		
        return false;
    });	
	
    jQuery(".skin-6").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-6.css");
		jQuery(".logo-header img").attr("src", "images/logo-6.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-6.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-6.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-6.png");
        return false;
    });		
		
    jQuery(".skin-7").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-7.css");
		jQuery(".logo-header img").attr("src", "images/logo-7.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-7.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-7.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-7.png");
        return false;
    });
	
    jQuery(".skin-8").on('click', function(){
        jQuery(".skin").attr("href", "css/skin/skin-8.css");
		jQuery(".logo-header img").attr("src", "images/logo-8.png");
		jQuery(".header-style-1.header-dark-1 .logo-header img").attr("src", "images/logo-light-8.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/logo-light-8.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/logo-8.png");
        return false;
    });	
		
});










